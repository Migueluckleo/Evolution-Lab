# Referencia administrativa · contrato promovido

La ubicación canónica es [foundations.icon-button-backgrounds.amendment.v0.1.9.md](../../specs/foundations/foundations.icon-button-backgrounds.amendment.v0.1.9.md). Esta ruta conserva compatibilidad; no define requisitos ni constituye otra especificación editable.

Promoción: 2026-10-06. DELEGATED_FOR_BUILD; auditoría humana PENDING. QA y sustituciones se detallan en el documento canónico. [Bytes anteriores archivados](../../archive/specs-promotion-2026-10-06/foundations.icon-button-backgrounds.amendment.v0.1.9.md); no son norma paralela vigente.
