# AGENTS.md

**Paquete de protocolos:** 0.2.0 · **Método:** Specs Driven Design (SDD)

## Propósito y alcance

Este repositorio documenta un sistema de diseño para reconstruirlo en Figma y, posteriormente, en frontend. SDD es el método; los contratos son archivos `.md` y pueden referenciar datos canónicos `.json`.

Este archivo orienta y dirige. Los procedimientos viven en los protocolos. No ejecutes todas las fases por haberlas leído: la solicitud actual determina qué acciones están autorizadas.

## Lectura y selección de protocolo

Lee este archivo, el protocolo de la tarea y sus dependencias indicadas. Consulta los registros existentes antes de asumir el estado del proyecto. No interpretes una ruta mencionada como prueba de que el archivo existe.

| ID | Protocolo | Cuándo utilizarlo |
|---|---|---|
| P01 | [Entorno y herramientas](protocols/01-ENVIRONMENT-AND-TOOLS.md) | Verificar o preparar herramientas, únicamente con autorización. |
| P02 | [Ingesta y almacenamiento](protocols/02-DOCUMENT-INGESTION-AND-STORAGE.md) | Recibir, clasificar, conservar y organizar fuentes. |
| P03 | [Construcción de contratos MD](protocols/03-CONTRACT-SYNTHESIS.md) | Transformar JSON, nodos de Figma y documentación en un contrato para revisión. |
| P04 | [Construcción en Figma](protocols/04-FIGMA-CONSTRUCTION.md) | Materializar un contrato aprobado y listo para ese destino. |
| P05 | [Autodocumentación y trazabilidad](protocols/05-SELF-DOCUMENTATION-AND-TRACEABILITY.md) | Registrar fuentes, decisiones, contratos, ejecución y evidencia. |
| P06 | [QA y validación](protocols/06-QA-AND-VALIDATION.md) | Revisar el contrato antes de aprobarlo y validar la implementación después. |

Flujo: **P02 → P03 → QA documental → aprobación humana → P04 → lectura del resultado → QA de implementación.** P01 se aplica según capacidades necesarias; P05 acompaña todas las fases.

Un contrato ya aprobado no necesita sintetizarse de nuevo: verifica su versión, aprobación, fuentes y dependencias antes de P04.

## Autoridad documental

Las instrucciones superiores de la herramienta, los permisos y la seguridad siguen vigentes. Dentro del proyecto:

- Las decisiones explícitas del usuario gobiernan el alcance. Un cambio de diseño debe registrarse antes de propagarse a implementaciones.
- La especificación vigente es el contrato aprobado junto con sus datos canónicos referenciados. El Markdown gobierna las reglas; el JSON gobierna los campos que el contrato le delega. No mantengas dos definiciones editables del mismo dato.
- Una enmienda aprobada solo sustituye los requisitos y versiones que identifica. No gana por ser más reciente o llamarse `corrected`.
- Ante contradicción entre fuentes aprobadas, registra `CONFLICT` y detén la operación afectada. No elijas silenciosamente por formato o apariencia.
- Inventarios sin aprobar, auditorías, ejemplos, Figma observado, código y Graphify son evidencia. No se convierten en norma por existir.

## Reglas globales

No inventes intención, tokens, estados, variantes, valores ni aprobaciones. Distingue `EXPLICIT`, `DERIVED`, `OBSERVED`, `INFERRED`, `UNRESOLVED` y `CONFLICT`; su procedencia no equivale a su aprobación. Un contrato sintetizado empieza en `DRAFT` y requiere aprobación humana explícita antes de construir. Aprobar un protocolo o una plantilla no aprueba contratos futuros.

Usa una sola `description` canónica por token. No crees `usage` ni descripciones paralelas. Conserva aliases y bindings; igualdad visual no implica igualdad semántica. Preserva fuentes originales e IDs de origen; registra los IDs reales de destino por separado.

Las plantillas de `templates/` no son contratos aprobados. No copies sus instrucciones editoriales a requisitos finales ni completes campos desconocidos con datos del ejemplo de Button.

**Destino de reconstrucción:** `AI-Design-System`, file key `tj3WIBEZDGLVs7MJWKCwgf`. P04 define la URL y la regla obligatoria de una página por familia de componente. El nodo fuente de extracción no sustituye este destino.

Graphify es un índice derivado, no una autoridad. Confirma los hallazgos contra la fuente. No regeneres el grafo sin permiso para esa operación. La pila web prevista sigue siendo React + TypeScript + Vite; su implementación no queda autorizada por la documentación.

## Estados y cierre

No confundas aprobación del contrato, preparación del destino y validación de la implementación. P03 define el ciclo documental; P05 registra el estado por destino; P06 define los criterios de cierre.

Sin fuentes suficientes puedes documentar un borrador parcial, pero no declararlo listo. Sin capacidad de escritura puedes sintetizar desde datos accesibles, pero no construir. Sin evidencia de QA no declares una implementación `VALIDATED`.

Antes de cerrar, registra qué leíste, qué cambiaste, qué comprobaste, qué sigue bloqueado y qué decisión se necesita. No uses la conversación como único registro persistente.
