# P04. Construcción en Figma

**Versión:** 0.2.0 · **Sustituye al antiguo P03 de construcción.**

## 1. Propósito y precondiciones

Materializar un contrato MD aprobado en el archivo de reconstrucción. Lee [AGENTS.md](../AGENTS.md), [P03](03-CONTRACT-SYNTHESIS.md), [P05](05-SELF-DOCUMENTATION-AND-TRACEABILITY.md) y la validación de implementación de [P06](06-QA-AND-VALIDATION.md).

Antes de escribir deben cumplirse todas estas condiciones: contrato aprobado y vigente para el alcance, JSON referenciado verificable si aplica, dependencias resueltas, preparación `READY` para Figma, permisos y capacidades comprobados con [P01](01-ENVIRONMENT-AND-TOOLS.md), y solicitud de construcción autorizada.

No construyas directamente desde un nodo fuente o un JSON recién recibido. Esos materiales pasan por P02/P03. No interpretes la aprobación de documentación operativa como aprobación del diseño.

## 2. Destino autorizado de reconstrucción

- Archivo: `AI-Design-System`.
- File key: `tj3WIBEZDGLVs7MJWKCwgf`.
- URL: `https://www.figma.com/design/tj3WIBEZDGLVs7MJWKCwgf/AI-Design-System?node-id=0-1`.

La página `0:1`/`Page 1` fue la referencia inicial compartida, no una garantía de su estado actual ni una página predeterminada para construir. Inspecciona el archivo antes de operar.

El Figma fuente de P03 y el destino de P04 son roles distintos. No sustituyas el destino porque un contrato contenga otro file key como procedencia. No escribas en la biblioteca original salvo instrucción explícita distinta del flujo normal.

## 3. Regla obligatoria: una página por familia de componente

Todos los componentes principales, component sets, variantes, tamaños, estados, ejemplos y documentación propia de una misma familia viven en una página dedicada. Button tiene su página; Badge otra; Input otra.

No crees páginas por variante, tamaño o estado. No mezcles familias no relacionadas. No utilices `Page 1` por conveniencia.

Antes de crear una página, lista las existentes, resuelve el nombre canónico de la familia desde el contrato y consulta el registro de implementaciones. Reutiliza la página correcta cuando exista. Si hay dos candidatas o una identidad ambigua, registra el conflicto en vez de duplicar.

Registra nombre y page ID reales. No inventes la taxonomía ni el nombre de página a partir de un ejemplo genérico. No muevas contenido ajeno para forzar esta regla sin autorización.

La composición puede usar instancias de dependencias en la página del componente consumidor; sus definiciones principales siguen en la página de su propia familia. No dupliques un componente principal para simular una dependencia.

Foundations/tokens no son familias de componentes. Su representación visual requiere una organización aprobada específica. Crear variables no obliga a inventar una página de muestras.

## 4. Preflight de cada construcción

Lee la versión exacta del contrato y datos. Confirma aprobación y que no haya cambios de fuentes posteriores. Inspecciona el estado real del destino, localiza implementaciones existentes y clasifica la tarea como `CREATE`, `UPDATE`, `MIGRATE` o `VALIDATE_ONLY`.

Prepara un plan con requisitos `REQ-...`, objetos afectados, dependencias, campos que se escribirán, bindings esperados y comprobaciones de lectura posterior. No añadas variantes por completar combinaciones teóricas.

Haz una captura estructural previa de los elementos que vayas a actualizar cuando la herramienta lo permita. No ejecutes cambios si no puedes determinar qué recurso estarías reemplazando.

## 5. Identidad y reconstrucción de tokens

Mantén separados los IDs de origen y los IDs asignados por el destino. No cambies el inventario original para reemplazarlos. Genera un mapa derivado de implementación que permita resolver:

```text
source file + collection ID + variable ID + mode ID
                ↓
destination file + collection ID + variable ID + mode ID
```

Crea/reutiliza primero las colecciones y modos requeridos, después las variables y finalmente los aliases cuando todas las referencias necesarias existan. Conserva nombres, valores, tipos, descripciones, scopes y `codeSyntax` aprobados; si una API no permite representarlos, registra `TOOL_LIMITATION`, no una equivalencia inventada.

Los aliases en el destino deben apuntar a sus variables correspondientes del destino según el mapa, no a IDs antiguos ni a valores literales resueltos. Comprueba las relaciones por identidad lógica, no por igualdad del color.

Los valores primitivos siguen siendo literales cuando así están definidos. La prohibición de hardcodear aplica a consumidores que deben usar una referencia, no a borrar los valores fuente del sistema.

Si una operación se interrumpe, lee qué se creó antes de repetirla. Actualiza el mapa y el diario por lote. No ejecutes toda la importación de nuevo a ciegas.

## 6. Construcción de componentes

Implementa únicamente anatomía, jerarquía, propiedades, variantes, estados, layout, dimensiones, contenido, tokens, interacciones y accesibilidad documentados para Figma.

Usa bindings reales donde los exige el contrato. Un color pegado con el mismo valor no satisface un binding. No sustituyas un token por otro de igual apariencia ni desacoples instancias para resolver faltantes.

Si hay una propiedad conceptual sin correspondencia demostrada en la herramienta, usa el mapeo aprobado o detén la operación afectada. No declares que Figma implementa comportamiento de navegador a partir de una etiqueta visual.

El diseño interno de la página sigue el contrato o una decisión de organización aprobada. No impongas nuevas secciones ni componentes para embellecer la documentación.

## 7. Cambios y recuperación

Trabaja en lotes pequeños y verificables, con dependencias antes que consumidores. Registra acciones planeadas y realizadas. La escritura parcial debe reflejarse como parcial, no como `IMPLEMENTED` de todo el componente.

Eliminar, reemplazar destructivamente, renombrar en bloque, desconectar instancias, aplanar o alterar relaciones requiere autorización explícita aplicable. La migración de contratos no autoriza por sí misma estas acciones.

Ante error, detén escrituras dependientes, lee el estado real, registra los recursos afectados y decide recuperación basada en evidencia. No prometas rollback automático si el adaptador no lo ofrece; usa restauración comprobable o escala.

## 8. Lectura posterior y cierre

Después de cada lote significativo y de la última corrección, lee los recursos reales. Comprueba identidad, página, jerarquía, propiedades, valores por modo, referencias y bindings disponibles. Captura respuestas y IDs para [P05](05-SELF-DOCUMENTATION-AND-TRACEABILITY.md).

Entrega el resultado a [P06](06-QA-AND-VALIDATION.md). Una respuesta exitosa de escritura no demuestra conformidad. Si solo puedes confirmar la creación pero no los atributos obligatorios, registra la limitación y no declares `VALIDATED`.

La implementación debe poder reconstruirse y compararse contra la misma especificación sin alterar el contrato para hacer pasar QA.
