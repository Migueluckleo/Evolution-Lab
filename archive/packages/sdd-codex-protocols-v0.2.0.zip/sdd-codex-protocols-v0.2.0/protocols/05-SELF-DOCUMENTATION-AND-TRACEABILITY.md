# P05. Autodocumentación y trazabilidad

**Versión:** 0.2.0 · **Sustituye al antiguo P04.**

## 1. Propósito

Mantener memoria verificable de qué fuentes entraron, qué contrato se elaboró, quién aprobó qué versión, qué se construyó, dónde y con qué resultado. Acompaña ingesta, síntesis, aprobación, construcción y QA. No inventa intención ni aprueba requisitos.

Lee [AGENTS.md](../AGENTS.md). Registra hechos, evidencias y razones resumidas; no se requieren monólogos internos ni una cadena privada de razonamiento.

## 2. Registros y responsabilidades

| Registro | Contenido propio |
|---|---|
| `registry/sources.md` | ID de fuente, ruta/URL, versión/snapshot, hash, rol, autoridad comprobada y cobertura. |
| `registry/contracts.md` | Identidad, ruta, versión, estado documental, datos referenciados y preparación por destino. |
| `registry/decisions.md` | Aprobaciones, rechazos, cambios autorizados y resolución de conflictos. |
| `registry/implementations.md` | Contrato/versión/datos → archivo, página, nodos y mapa de IDs reales. |
| `registry/qa.md` | Tipo de revisión, versión, requisitos, evidencias y resultado. |
| `registry/environment.md` | Herramientas/capacidades verificadas, configuración sin secretos y estado del grafo. |

Crea solo los registros que la tarea necesita. No reemplaces registros existentes por plantillas vacías. Usa rutas relativas y vínculos reales cuando exista el recurso. Una ruta prevista debe marcarse como prevista, no como entregable generado.

## 3. Estado en dimensiones separadas

No uses un único `status` para describir todo el proyecto.

- Fuentes: `RECEIVED`, `INDEXED`, `BLOCKED`, `CONFLICT`, `SUPERSEDED`.
- Contratos: `DRAFT`, `IN_REVIEW`, `APPROVED`, `REJECTED`, `SUPERSEDED`, según [P03](03-CONTRACT-SYNTHESIS.md).
- Preparación de cada destino: `READY`, `BLOCKED`, `CONFLICT`.
- Implementación por destino: `NOT_STARTED`, `IMPLEMENTING`, `IMPLEMENTED`, `VALIDATING`, `VALIDATED`, `VALIDATED_WITH_EXCEPTIONS`, `FAILED`, `STALE`.

La preparación ausente significa desconocida, no `READY`. Un contrato puede estar aprobado para Figma y tener web fuera de alcance. Una implementación puede estar validada contra una versión anterior y quedar `STALE` frente a la nueva.

Los estados extendidos de 0.2.0 deben migrarse desde los registros anteriores conservando su historial, no reasignarse masivamente sin evidencia.

## 4. Trazabilidad de síntesis

Para cada contrato candidato registra fuentes exactas, localizadores, transformaciones, cobertura, requisitos candidatos y reporte de síntesis. Usa la [plantilla de reporte](../templates/contract-synthesis-report.template.md).

Ejemplo de campos del registro, no de un contrato real:

```yaml
contract_id: null
path: null
version: null
document_status: DRAFT
source_refs: []
source_digests: []
synthesis_report: null
document_qa_record: null
approval_decision: null
readiness_by_target: {}
```

Completa los campos con evidencia. No asignes `owner: Design System`, un paquete de React o `stable` porque aparecían en el ejemplo educativo.

## 5. Aprobaciones y decisiones

Registra quién decidió, fecha real, solicitud o respuesta que autoriza, entidad, versión, alcance, requisitos adoptados y vínculos a fuentes. Para aprobación, conserva digest del candidato revisado, digest del contrato publicado y de sus datos vinculados, según el procedimiento de P03.

No edites requisitos durante una promoción administrativa. Si cambian requisitos, vuelve a revisión. Un rechazo conserva su razón y la revisión rechazada. Una aprobación no retroactiva no convierte ejecuciones previas no autorizadas en correctas.

## 6. Trazabilidad de implementación

Para cada lote significativo registra:

```yaml
implementation_id: null
artifact_name: null
artifact_type: null
target: figma
implementation_status: NOT_STARTED
contract_ref: null
contract_version: null
contract_digest: null
data_refs: []
source_refs: []
dependency_refs: []
target_locator:
  file_key: null
  page_id: null
  node_ids: []
id_mapping_ref: null
operation: null
tool_and_version: null
before_evidence: []
actions_completed: []
after_evidence: []
qa_record: null
known_deviations: []
timestamp: null
```

No declares una operación realizada cuando solo fue planeada. Separa el binding esperado del binding efectivamente leído. No guardes claves API ni credenciales dentro de registros o snapshots.

## 7. Historia y sustituciones

El ID lógico de un contrato sobrevive a movimientos y revisiones. Registra `supersedes` y `superseded_by`; conserva el historial sin mantener dos versiones activas para el mismo alcance.

Los hashes se calculan, no se transcriben como prueba de ejecución. Diferencia SHA-256 de bytes de cualquier serialización canónica o hash que excluya campos. Registra el método si se usan distintos digests.

Si cambia un contrato o JSON que sostiene una implementación, identifica consumidores afectados y marca necesidad de revalidación. No sustituyas la referencia de una implementación antigua por la versión nueva sin reconstrucción o QA.

## 8. Graphify y persistencia

Graphify no sustituye los registros ni decide aprobación. Consulta el grafo vigente para localizar fuentes, pero abre la fuente exacta para validar la afirmación. Un borrador indexado sigue siendo borrador.

Después de cambios relevantes, registra si el grafo requiere actualización. Actualízalo únicamente dentro del alcance autorizado y con [P01](01-ENVIRONMENT-AND-TOOLS.md). La migración documental inicial deja el grafo pendiente de actualización, no simula una regeneración.

## 9. Salida al usuario

Explica qué se recibió, redactó o construyó; desde qué fuentes; qué comprobaciones se ejecutaron; qué está aprobado y qué no; qué bloquea la siguiente fase. Usa vínculos a archivos/IDs verificables y no afirmes validaciones inexistentes.

El criterio de cierre es que otro agente pueda continuar con los archivos del proyecto sin depender de esta conversación ni confundir una plantilla con un contrato vigente.
