# Changelog del paquete de protocolos

## 0.2.0 · 2026-09-22

### Añadido

P03 de construcción de contratos Markdown desde JSON, nodo Figma y fuentes combinadas. Incluye clasificación de evidencia, requisitos candidatos, cobertura, reporte, revisión documental y aprobación humana de versión/alcance.

Plantillas diferenciadas para componentes y foundations, más reporte de síntesis. La de componentes conserva las 21 secciones del ejemplo educativo, pero no importa sus valores ni reglas como verdad del proyecto.

Prompts separados para integrar la actualización y para sintetizar contratos cuando se entreguen fuentes reales. Documento de migración, manifiesto de integridad y verificación del paquete.

### Renumerado

Construcción Figma pasa de P03 a P04; autodocumentación de P04 a P05; QA de P05 a P06. Se actualizan sus enlaces activos.

### Cambios de gobernanza declarados

La ingesta ya no conduce directamente a construcción. Un contrato sintetizado debe pasar por DRAFT/IN_REVIEW y aprobación humana antes de P04.

Se separan el estado documental del contrato, la preparación por destino y el estado de implementación. Una excepción aceptada se muestra como `VALIDATED_WITH_EXCEPTIONS`, sin ocultar la diferencia.

Se precisa la autoridad por responsabilidad: el MD aprobado gobierna las reglas y el JSON aprobado los campos delegados. Esto sustituye la simplificación anterior de que el formato Markdown siempre ganaba a un JSON. Una contradicción debe resolverse, no sobreescribirse por formato.

Las enmiendas aprobadas son sustituciones acotadas por entidad, versión y requisito; no quedan inútilmente subordinadas a una versión anterior ni adquieren autoridad global por fecha.

### Ampliado

Trazabilidad para fuentes, borradores, requisitos, decisiones y digests. QA documental separado de QA de implementación. Gestión de cobertura parcial, unidades desconocidas, estados simultáneos, mapeos por plataforma e identidad origen/destino.

La lectura de un nodo Figma en P03 se diferencia de la escritura de P04. Graphify y sus bloques/configuración existentes se preservan durante la migración.

### Conservado

Repositorio como fuente de especificación; una sola `description` por token; aliases y bindings; originales intactos; destino Figma acordado; una página por familia de componente; React + TypeScript + Vite como pila prevista, no instalada por esta entrega.

## Paquete anterior, identificado como 0.1 durante la conversación

Cinco protocolos: entorno, ingesta, construcción Figma, autodocumentación y QA. Sin fase formal de síntesis de contratos antes de construir. Su estado se conserva en los respaldos del proyecto al migrar; no se incluye como una segunda versión activa en este paquete.
