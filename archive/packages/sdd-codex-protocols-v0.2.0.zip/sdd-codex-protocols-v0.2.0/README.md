# Specs Driven Design · Protocolos para Codex

**Versión del paquete:** 0.2.0 · **Fecha:** 2026-09-22

Documentación operativa para convertir fuentes del sistema de diseño en contratos Markdown aprobados y, después, reconstruirlos en Figma. No es una aplicación, un instalador ni un sincronizador ya ejecutado.

## Qué cambia

Se incorpora **P03: Contract Synthesis** antes de construcción. El agente ya no salta desde un JSON organizado a Figma: redacta un contrato candidato, lo contrasta con las fuentes y espera aprobación humana explícita.

```text
JSON / nodo Figma / documentación
                ↓
       P02 · Ingesta y almacenamiento
                ↓
       P03 · Contrato MD candidato
                ↓
       P06 · QA documental
                ↓
       Aprobación humana de versión y alcance
                ↓
       P04 · Construcción en Figma
                ↓
       Readback + P06 · QA de implementación

P01 comprueba capacidades cuando hacen falta.
P05 registra evidencia y estado durante todo el recorrido.
```

## Archivos principales

| Archivo | Función |
|---|---|
| [AGENTS.md](AGENTS.md) | Orientación y acceso a los seis protocolos. |
| [P01](protocols/01-ENVIRONMENT-AND-TOOLS.md) | Instalación y verificación técnica, bajo autorización. |
| [P02](protocols/02-DOCUMENT-INGESTION-AND-STORAGE.md) | Clasificación, originales, ubicación y procedencia. |
| [P03](protocols/03-CONTRACT-SYNTHESIS.md) | Síntesis desde JSON, nodo Figma o fuentes combinadas. |
| [P04](protocols/04-FIGMA-CONSTRUCTION.md) | Construcción desde contrato aprobado; página por familia. |
| [P05](protocols/05-SELF-DOCUMENTATION-AND-TRACEABILITY.md) | Registros, decisiones, versiones e identidad de destinos. |
| [P06](protocols/06-QA-AND-VALIDATION.md) | Revisión documental y validación posterior separadas. |
| [Plantilla de componente](templates/component.contract.template.md) | Las 21 secciones del ejemplo, sin heredar sus datos. |
| [Plantilla de foundations](templates/foundations.contract.template.md) | Contrato que referencia el inventario canónico. |
| [Reporte de síntesis](templates/contract-synthesis-report.template.md) | Evidencia, cobertura, propuestas y preguntas. |
| [Migración](MIGRATION-v0.2.0.md) | Incorporación controlada al proyecto existente. |
| [Prompt de integración](prompts/01-INTEGRATE-PROTOCOLS.md) | Instrucción para actualizar ahora sin construir. |
| [Prompt de síntesis](prompts/02-SYNTHESIZE-CONTRACT.md) | Instrucción para cuando se entreguen fuentes reales. |
| [Changelog](CHANGELOG.md) | Cambios operativos de esta versión. |
| [Fuentes documentales](references/DOCUMENTATION-SOURCES.md) | Alcance de los referentes utilizados. |
| [Verificación del paquete](PACKAGE-VERIFICATION.md) | Comprobaciones locales realizadas antes de entregar. |

## Cómo entregarlo a Codex

Descomprime el ZIP y coloca la carpeta completa `sdd-codex-protocols-v0.2.0/` dentro del proyecto como material de actualización. No sueltes los protocolos uno por uno en la raíz y no sobrescribas todavía el AGENTS activo.

Desde la raíz real del proyecto, pega el [prompt de integración](prompts/01-INTEGRATE-PROTOCOLS.md). Codex debe aplicar [MIGRATION-v0.2.0.md](MIGRATION-v0.2.0.md), preservar mejoras locales y respaldar lo reemplazado. El resultado activo tendrá `AGENTS.md` en la raíz y los seis protocolos dentro de `protocols/`.

La carpeta recibida es un paquete de actualización, no una nueva raíz operativa. El código, configuración y registros existentes no se reinicializan.

Tras la migración, para que el inicio de la siguiente sesión use la nueva cadena de instrucciones, abre una nueva sesión de Codex en la raíz. La documentación oficial describe que esa cadena se prepara al inicio de cada ejecución/sesión. Referencia: `https://developers.openai.com/codex/guides/agents-md/`.

Cuando entregues JSON o un nodo fuente, utiliza el segundo prompt. No se han incluido en este paquete inventarios JSON, contratos reales ni una aprobación del componente Button.

## Reglas que se mantienen

La especificación aprobada en el repositorio gobierna Figma y web. El MD expresa reglas y referencia datos canónicos; la `description` de cada token mantiene un único propietario. Graphify es navegación y no aprobación. Crear algo no demuestra que cumpla.

El destino acordado sigue siendo `AI-Design-System`, file key `tj3WIBEZDGLVs7MJWKCwgf`. Cada familia de componentes principales tiene una página. Variantes, tamaños y estados de Button no generan páginas independientes.

## Lo que este paquete no resuelve por sí solo

No identifica automáticamente el proveedor de Figma MCP instalado, no acredita sus permisos y no instala Graphify. Una URL de diseño no es una URL de instalación. La fase de entorno debe comprobar capacidades reales cuando se autorice.

Las nuevas plantillas son herramientas de redacción, no valores por defecto del sistema. El esquema de metadatos, los IDs de requisitos y los estados documentales son convenciones de este proyecto, no una afirmación de que exista un estándar universal de contratos SDD.

El paquete incluye un manifiesto `SHA256SUMS.txt` para comprobar integridad de los archivos entregados. No constituye una firma digital ni aprobación del diseño.
